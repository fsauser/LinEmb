#include <iostream> 
#include <stdio.h>
#include <cstring>

using namespace std;

int main (int argc, char* argv[])
{
  int c, i, j, k;
  char ip[64];
  char line[128];
  char model[64];
  char release[64];
  char cpu[8];
  
  FILE *f = popen("ip a | grep 'scope global' | awk '{print $2}' | cut -d '/' -f1", "r");
  
  c = getc(f);
  i = 0;
  while (c != EOF)
  {
    i += sprintf(ip+i, "%c", c);
    c = getc(f);
  }
  pclose(f);
  cout << "Adresse IP : " << ip;
   
  f = popen("cat /etc/os-release", "r");
  char strOS[]="PRETTY_NAME=";
  while (fgets(line, sizeof(line), f))
  {
  	if (strncmp(line, strOS, sizeof(strOS)-1)==0)
  	{
  		for(j=0;j<(int)sizeof(line)-1;j++)
  		{
  			if (line[j] == '=') break;
  		}
  		for(i=j+1;i<(int)sizeof(line)-1;i++)
  		{
  			if (line[i] == '\0') break;
  		}
        sprintf(release, "%.*s", i-j, &line[j+1]);
  	}
  }
  pclose(f);
  cout << "Nom de la release : " << release;


  f = popen("lscpu", "r");
  char strModel[]="Model name:";
  char strCPU[]="CPU(s):";
  while (fgets(line, sizeof(line), f))
  {
  	if (strncmp(line, strCPU, sizeof(strCPU)-1)==0)
  	{
  		for(j=0;j<(int)sizeof(line)-1;j++)
  		{
  			if (line[j] == ':') break;
  		}
  		for(k=j+1;k<(int)sizeof(line)-1;k++)
  		{
  			if (line[k] != ' ') break;
  		}
  		for(i=k+1;k<(int)sizeof(line)-1;i++)
  		{
  			if (line[i] == '\0') break;
  		}
        sprintf(cpu, "%.*s", i-k, &line[k]);
  	}
  	if (strncmp(line, strModel, sizeof(strModel)-1)==0)
  	{
  		for(j=0;j<(int)sizeof(line)-1;j++)
  		{
  			if (line[j] == ':') break;
  		}
  		for(k=j+1;k<(int)sizeof(line)-1;k++)
  		{
  			if (line[k] != ' ') break;
  		}
  		for(i=k+1;k<(int)sizeof(line)-1;i++)
  		{
  			if (line[i] == '\0') break;
  		}
        sprintf(model, "%.*s", i-k, &line[k]);
  	}
  }
  pclose(f);

  cout << "Nombre de CPU : " << cpu;
  cout << "Type du processeur : " << model;


  return 0;
}


