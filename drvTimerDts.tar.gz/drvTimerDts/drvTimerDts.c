#include <linux/module.h>
#include <linux/init.h>
#include <linux/mod_devicetable.h>
#include <linux/property.h>
#include <linux/platform_device.h>
#include <linux/of_device.h>
#include <linux/gpio/consumer.h>
#include <linux/jiffies.h>
#include <linux/timer.h>
 #include <linux/version.h>

/* Meta Information */
MODULE_LICENSE("GPL");
MODULE_AUTHOR("HE-ARC/FSA/JSE");
MODULE_DESCRIPTION("Driver with device tree overlay my_gpio");

/* Declate the probe and remove functions */
static int drvTimerDts_probe(struct platform_device *pdev);
static int drvTimerDts_remove(struct platform_device *pdev);

static struct of_device_id leds_driver_ids[] = {
  {
    .compatible = "hearc,hearc-gpio-driver",
  }, { /* sentinel */ }
};
MODULE_DEVICE_TABLE(of, leds_driver_ids);

static struct platform_driver leds_driver = {
    .probe = drvTimerDts_probe,
    .remove = drvTimerDts_remove,
    .driver =  {
        .name = "leds_hearc_driver",
        .of_match_table = leds_driver_ids,
    },
};

/* GPIO variable */
static struct gpio_desc *red = NULL, *green = NULL, *blue = NULL;

/* Timer */
void timerLED_fct(struct timer_list *);
struct timer_list timerLED;
static uint16_t timerSpeed = 500;

/**
 * @brief This function is called on loading the driver
 */
static int drvTimerDts_probe(struct platform_device *pdev)
{
  struct device *dev = &pdev->dev;
  const char *label;
  int ret;

  pr_info("drvTimerDts - Probe function in\n");

  /* Check for device properties */
  if(!device_property_present(dev, "label"))
  {
    pr_err("drvTimerDts - Device property 'label' not found\n");
    return -1;
  }

  /* Read device properties */
  ret = device_property_read_string(dev, "label", &label);
  if(ret)
  {
    pr_err("drvTimerDts - Could not read 'label'\n");
    return -1;
  }
  pr_info("%s\n", label);

  /* Init GPIO */
  red = gpiod_get_index(dev, "hearc", 0, GPIOD_OUT_HIGH);
  gpiod_set_consumer_name(red, "Led-red/drvTimerDts");
  if(IS_ERR(red))
  {
    pr_err("drvTimerDts - Could not setup the GPIO (0)\n");
    return -1 * IS_ERR(red);
  }

  green = gpiod_get_index(dev, "hearc", 1, GPIOD_OUT_HIGH);
  gpiod_set_consumer_name(green, "Led-green/drvTimerDts");
  if(IS_ERR(green))
  {
    pr_err("drvTimerDts - Could not setup the GPIO (1)\n");
    return -1 * IS_ERR(green);
  }
  blue = gpiod_get_index(dev, "hearc", 2, GPIOD_OUT_HIGH);
  gpiod_set_consumer_name(blue, "Led-blue/drvTimerDts");
  if(IS_ERR(blue))
  {
    pr_err("drvTimerDts - Could not setup the GPIO (2)\n");
    return -1 * IS_ERR(blue);
  }

  //set timer
  timer_setup(&timerLED, timerLED_fct, 0);
  mod_timer(&timerLED, jiffies + msecs_to_jiffies(timerSpeed));
  return 0;
}

/**
 * @brief This function is called on unloading the driver
 */
#if LINUX_VERSION_CODE >= KERNEL_VERSION(6,10,0)
static int drvTimerDts_remove(struct platform_device *pdev)
#else
static void drvTimerDts_remove(struct platform_device *pdev)
#endif
{
  pr_info("drvTimerDts - Remove function in\n");
  del_timer(&timerLED);
  gpiod_put(red);
  gpiod_direction_input(red);
  gpiod_put(green);
  gpiod_direction_input(green);
  gpiod_put(blue);
  gpiod_direction_input(blue);
#if LINUX_VERSION_CODE >= KERNEL_VERSION(6,10,0)
  return 0;
#endif  
}


void timerLED_fct(struct timer_list *timer)
{
  static int count = 0;

  mod_timer(&timerLED, jiffies + (msecs_to_jiffies(timerSpeed)));
  //pr_info("Timer Occurred : Led --> %d\n", count);
  if (count == 0)
  {
    gpiod_set_value(red, 1);
    gpiod_set_value(green, 0);
    gpiod_set_value(blue, 0);
    count++;
  }
  else if (count == 1)
  {
    gpiod_set_value(red, 0);
    gpiod_set_value(green, 1);
    gpiod_set_value(blue, 0);
    count++;
  }
  else if (count > 1)
  {
    gpiod_set_value(red, 0);
    gpiod_set_value(green, 0);
    gpiod_set_value(blue, 1);
    count = 0;
  }  
}

/**
 * @brief This function is called, when the module is loaded into the kernel
 */
static int __init drvTimerDts_init(void)
{
  pr_info("drvTimerDts - Loading the driver...\n");
  if(platform_driver_register(&leds_driver))
  {
    pr_err("drvTimerDts - Could not load driver\n");
    return -1;
  }
  return 0;
}

/**
 * @brief This function is called, when the module is removed from the kernel
 */
static void __exit drvTimerDts_exit(void)
{
  pr_info("drvTimerDts - Unload driver\n");
  platform_driver_unregister(&leds_driver);
}

module_init(drvTimerDts_init);
module_exit(drvTimerDts_exit);


