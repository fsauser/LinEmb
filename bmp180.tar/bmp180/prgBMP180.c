/********************************************************************************************
*Filename      : bmp180Ex.c
*Description   : bmp180 Example
*
*           BMP180----------------------- Pi
*            3.3 ----------------------- 3.3V
*            GND ----------------------- GND
*            SDA ----------------------- SDA1
*            SCL ----------------------- SCL1
********************************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <linux/i2c-dev.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <math.h>
#include <errno.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>
#include "bmp180.h"

#define OSS BMP180_STANDARD
int16_t AC1,AC2,AC3,B1,B2,MB,MC,MD;
uint16_t AC4,AC5,AC6;
int fd;

int I2C_setup()
{
    // Create I2C bus
    static char *bus = "/dev/i2c-1";
    if((fd = open(bus, O_RDWR)) < 0)
    {
        printf("Failed to open the bus. \n");
        return -1;
    }
	ioctl(fd, I2C_SLAVE, BMP180_Address);

    return 0;
}

int8_t I2C_readByte(int8_t reg)
{
    int8_t data;
	write(fd, &reg, 1);
    read(fd, &data, 1);

    return data;
}

int16_t I2C_readWord(int8_t reg)
{
    int8_t data[2];
    int16_t result = 0;
	write(fd, &reg, 1);
    read(fd, &data, 2);
    result = (int16_t)data[1];
    result *= 256;
    result += (int16_t)data[0];
    return result;
}

uint16_t I2C_readU16(int8_t reg)
{
    int16_t MSB,LSB;
    int8_t data[2];
    write(fd, &reg, 1);
    read(fd, data, 2);
    MSB = data[0];
    LSB = data[1];
    uint16_t value = (MSB << 8) + LSB;
    return value;
}

int16_t I2C_readS16(int8_t reg)
{
    int16_t result = (int16_t)I2C_readU16(reg);
    if (result > 32767)result -= 65536;
    return result;
}
void I2C_writeWord(int8_t reg,int8_t val)
{
    int8_t data[2] = {reg, val};
    write(fd, data, 2);
}

void load_calibration()
{
    AC1 = I2C_readS16(BMP180_CAL_AC1);
    AC2 = I2C_readS16(BMP180_CAL_AC2);
    AC3 = I2C_readS16(BMP180_CAL_AC3);
    AC4 = I2C_readU16(BMP180_CAL_AC4);
    AC5 = I2C_readU16(BMP180_CAL_AC5);
    AC6 = I2C_readU16(BMP180_CAL_AC6);
    B1  = I2C_readS16(BMP180_CAL_B1);
    B2  = I2C_readS16(BMP180_CAL_B2);
    MB  = I2C_readS16(BMP180_CAL_MB);
    MC  = I2C_readS16(BMP180_CAL_MC);
    MD  = I2C_readS16(BMP180_CAL_MD);
}

int16_t read_raw_temp()
{
    int16_t MSB,LSB, result;
    I2C_writeWord(BMP180_CONTROL,BMP180_READTEMPCMD);
    usleep(5000);  //5ms;
    MSB = I2C_readByte(BMP180_TEMPDATA);
    LSB = I2C_readByte(BMP180_TEMPDATA+1);
    result = (MSB<<8)+LSB;
    return result;

}
int32_t read_raw_pressure()
{
    uint8_t MSB,LSB,XLSB;
    int32_t raw;
    I2C_writeWord(BMP180_CONTROL,BMP180_READPRESSURECMD +(OSS << 6));
    switch(OSS)
    {
        case BMP180_ULTRALOWPOWER:
            usleep(5000);break;
        case BMP180_HIGHRES:
            usleep(14000);break;
        case BMP180_ULTRAHIGHRES:
            usleep(26000);break;
        default :
            usleep(8000);
    }
    MSB  = I2C_readByte(BMP180_PRESSUREDATA);
    LSB  = I2C_readByte(BMP180_PRESSUREDATA + 1);
    XLSB = I2C_readByte(BMP180_PRESSUREDATA + 2);
    raw = (((int32_t)MSB << 16) + ((int32_t)LSB << 8) + XLSB) >> (8 - OSS);
    return raw;
}
float read_temperature()
{
    float T;
    int16_t UT,X1,X2,B5;
    UT = read_raw_temp();
    X1 = ((UT - AC6)*AC5) >> 15;
    X2 = (MC << 11) / (X1 + MD);
    B5 = X1 + X2;
    T = ((B5 + 8) >> 4) /10.0;
    return T;
}

int32_t read_pressure()
{
    int P;
    int32_t UT,UP,X1,X2,X3,B3,B5,B6;
    uint32_t B4;
    uint32_t B7;
    UT = (int32_t)read_raw_temp();
    UP = read_raw_pressure();

    X1 = ((UT - AC6)*AC5) >> 15;
    X2 = (MC << 11) / (X1 + MD);
    B5 = X1 + X2;

    //Pressure Calculations
    B6 = B5 - 4000;
    X1 = (B2 * (B6 * B6) >> 12) >> 11;
    X2 = (AC2 * B6) >> 11;
    X3 = X1 + X2;
    B3 = (((AC1 * 4 + X3) << OSS) + 2) / 4;
    X1 = (AC3 * B6) >> 13;
    X2 = (B1 * ((B6 * B6) >> 12)) >> 16;
    X3 = ((X1 + X2) + 2) >> 2;
    B4 = (AC4 * (X3 + 32768)) >> 15;
    B7 = (UP - B3) * (50000 >> OSS);
    if (B7 < 0x80000000){P = (B7 * 2) / B4;}
    else {P = (B7 / B4) * 2;}
    X1 = (P >> 8) * (P >> 8);
    X1 = (X1 * 3038) >> 16;
    X2 = (-7357 * P) >> 16;
    P = P + ((X1 + X2 + 3791) >> 4);
    return P;

}
float read_altitude()
{
    float pressure,altitude;
    float sealevel_pa = 101325.0;
    pressure = (float)read_pressure();
    altitude = 44330.0 * (1.0 - pow(pressure / sealevel_pa,(1.0/5.255)));
    return altitude;
}
float read_sealevel_pressure()
{
    float altitude_m = 0.0;
    float pressure,p0;
    pressure =(float)read_pressure();
    p0 = pressure / pow(1.0 - altitude_m/44330.0,5.255);
    return p0;
}
int main(int argc,char **argv)
{
    printf("BMP180 Test Program ...\n");
    if(I2C_setup() < 0) return 1;
    load_calibration();
    while(1)
    {
        printf("\nTemperature : %.2f C\n",read_temperature());
        printf("Pressure :    %.2f Pa\n",read_pressure()/100.0);
        printf("Altitude :    %.2f h\n",read_altitude());
        usleep(1000000);
    }
    return 0;
}

