#include <linux/module.h>
#include <linux/init.h>
#include <linux/mod_devicetable.h>
#include <linux/property.h>
#include <linux/platform_device.h>
#include <linux/of_device.h>
#include <linux/gpio/consumer.h>

/* Meta Information */
MODULE_LICENSE("GPL");
MODULE_AUTHOR("HE-ARC/FSA/JSE");
MODULE_DESCRIPTION("Driver with device tree overlay my_overlay");

/* Declate the probe and remove functions */
static int drvTestDts_probe(struct platform_device *pdev);
static int drvTestDts_remove(struct platform_device *pdev);

static struct of_device_id my_driver_ids[] = {
  {
    .compatible = "hearc,hearc-gpio-driver",
  }, { /* sentinel */ }
};
MODULE_DEVICE_TABLE(of, my_driver_ids);

static struct platform_driver my_driver = {
    .probe = drvTestDts_probe,
    .remove = drvTestDts_remove,
    .driver =  {
        .name = "my_hearc_driver",
        .of_match_table = my_driver_ids,
    },
};


/**
 * @brief This function is called on loading the driver
 */
static int drvTestDts_probe(struct platform_device *pdev)
{
  struct device *dev = &pdev->dev;
  const char *label;
  int ret;

  pr_info("drvTestDts - Probe function in\n");

  /* Check for device properties */
  if(!device_property_present(dev, "label"))
  {
    pr_err("drvTestDts - Device property 'label' not found\n");
    return -1;
  }

  /* Read device properties */
  ret = device_property_read_string(dev, "label", &label);
  if(ret)
  {
    pr_err("drvTestDts - Could not read 'label'\n");
    return -1;
  }
  pr_info("%s\n", label);

  return 0;
}

/**
 * @brief This function is called on unloading the driver
 */
static int drvTestDts_remove(struct platform_device *pdev)
{
  pr_info("drvTestDts - Remove function in\n");
  return 0;
}



/**
 * @brief This function is called, when the module is loaded into the kernel
 */
static int __init drvTestDts_init(void)
{
  pr_info("drvTestDts - Loading the driver...\n");
  if(platform_driver_register(&my_driver))
  {
    pr_err("drvTestDts - Could not load driver\n");
    return -1;
  }
  return 0;
}

/**
 * @brief This function is called, when the module is removed from the kernel
 */
static void __exit drvTestDts_exit(void)
{
  pr_info("drvTestDts - Unload driver\n");
  platform_driver_unregister(&my_driver);
}

module_init(drvTestDts_init);
module_exit(drvTestDts_exit);


