/***************************************************************************//**
*  \file       drvTestI2C.c
*
*  \details    Simple I2C driver explanation 
*
*  \author     FSA
*
* *******************************************************************************/
#include <linux/module.h>
#include <linux/init.h>
#include <linux/slab.h>
#include <linux/i2c.h>
#include <linux/delay.h>
#include <linux/kernel.h>
#include <linux/kthread.h>   
#include <linux/uaccess.h>      /* Required for the copy to user function		*/      
#include <linux/fs.h>           /* Header for the Linux file system support 	*/ 

#define I2C_BUS_AVAILABLE   (          1 )              // I2C Bus available in our Raspberry Pi
#define SLAVE_DEVICE_NAME   ( "TCS34725" )              // Device and Driver Name
#define TCS_SLAVE_ADDR      (       0x29 )              // TCS34725 Slave Address
 
static struct i2c_adapter *tcs_i2c_adapter = NULL;  	// I2C Adapter Structure
static struct i2c_client  *tcs_i2c_client  = NULL;  	// I2C Cient Structure 
static char dataRGB[3] = {1,2,3};
static short size_of_msg = 3;

#define  DEVICE_NAME "drvTestI2C"	/* The device will appear at /dev/drvTest using this value	*/
#define  CLASS_NAME  "hearc"   	/* The device class -- this is a character device driver	*/

MODULE_LICENSE("GPL");         	
MODULE_AUTHOR("FSA");    		
MODULE_DESCRIPTION("A simple Linux char driver for RPi4"); 	
MODULE_VERSION("0.1");   

static int    majorNumber;                 	/* Device number -- determined automatically			*/
static struct class*  devTestClass  = NULL; /* The device-driver class struct pointer				*/
static struct device* devTestDevice = NULL; /* The device-driver device struct pointer				*/
 
// Prototype functions for the character driver
static void 	TCS_Read(unsigned char * data);
static int     	dev_open(struct inode *, struct file *);
static int     	dev_release(struct inode *, struct file *);
static ssize_t 	dev_read(struct file *, char *, size_t, loff_t *);
 
static struct file_operations fops =
{
   .open = dev_open,
   .read = dev_read,
//   .write = dev_write,
   .release = dev_release,
};
 
static struct task_struct *thread;
/*
** Thread
*/
int thread_function(void *pv)
{
   	char data[8] = {0};
   	int cData;
	//int red, green, blue;
   	
    while(!kthread_should_stop()) {
        //pr_info("Thread Function %d\n", i++);
        TCS_Read(data);
       	// Convert the data
		cData = (data[1] * 256 + data[0]);
		dataRGB[0] = (data[3] * 256 + data[2]);
		dataRGB[1] = (data[5] * 256 + data[4]);
		dataRGB[2] = (data[7] * 256 + data[6]);
		msleep(2000);
    }
    return 0;
}

/*
** This function writes the data into the I2C client
**
**  Arguments:
**      buff -> buffer to be sent
**      len  -> Length of the data
**   
*/
static int I2C_Write(unsigned char *buf, unsigned int len)
{
    /*
    ** Sending Start condition, Slave address with R/W bit, 
    ** ACK/NACK and Stop condtions will be handled internally.
    */ 
    int ret = i2c_master_send(tcs_i2c_client, buf, len);
    
    return ret;
}
 
/*
** This function reads one byte of the data from the I2C client
**
**  Arguments:
**      out_buff -> buffer wherer the data to be copied
**      len      -> Length of the data to be read
** 
*/
static int I2C_Read(unsigned char *out_buf, unsigned int len)
{
    /*
    ** Sending Start condition, Slave address with R/W bit, 
    ** ACK/NACK and Stop condtions will be handled internally.
    */ 
    int ret = i2c_master_recv(tcs_i2c_client, out_buf, len);
    
    return ret;
}
 
/*
** This function sends the command/data to the TCS.
**
**  Arguments:
**      data   -> data to be written
** 
*/
static void TCS_Write(unsigned char * data)
{
    //unsigned char buf[2] = {0};
    int ret;
    
    ret = I2C_Write(data, 2);
}

/*
** This function reads the data to the TCS.
**
**  Arguments:
**      data   -> data to be read
** 
*/
static void TCS_Read(unsigned char * data)
{
    int ret;
  	// Read 8 bytes of data from register(0x94)
	// cData lsb, cData msb, red lsb, red msb, green lsb, green msb, blue lsb, blue msb
	char reg[1] = {0x94};
	  
	ret = I2C_Write(reg, 1);  
    ret = I2C_Read(data, 8);
}
  
/*
** This function sends the commands that need to used to Initialize the TCS.
**
**  Arguments:
**      none
** 
*/

static int TCS_init(void)
{
	char config[2] = {0};
	char data[8] = {0};
	int cData;
	int red, green, blue;
	//float luminance;
    msleep(10);               // delay
 
    //
    // Commands to initialize the TCS
    //
    
    // Select enable register(0x80)
	// Power ON, RGBC enable, wait time disable(0x03)
	config[0] = 0x80;
	config[1] = 0x03;
	TCS_Write(config);
	// Select ALS time register(0x81)
	// Atime = 700 ms(0x00)
	config[0] = 0x81;
	config[1] = 0x00;
	TCS_Write(config);
	// Select Wait Time register(0x83)
	// WTIME : 2.4ms(0xFF)
	config[0] = 0x83;
	config[1] = 0xFF;
	TCS_Write(config);
	// Select control register(0x8F)
	// AGAIN = 1x(0x00)
	config[0] = 0x8F;
	config[1] = 0x00;
	TCS_Write(config);
	msleep(1);
	
	TCS_Read(data);
	// Convert the data
	cData = (data[1] * 256 + data[0]);
	red = (data[3] * 256 + data[2]);
	green = (data[5] * 256 + data[4]);
	blue = (data[7] * 256 + data[6]);

	// Calculate luminance
	/*luminance = (-0.32466) * (red) + (1.57837) * (green) + (-0.73191) * (blue);
	if(luminance < 0)
	{
		luminance = 0;
	}*/

	// Output data to screen
	pr_info("Red color luminance : %d lux \n", red);
	pr_info("Green color luminance : %d lux \n", green);
	pr_info("Blue color luminance : %d lux \n", blue);
	pr_info("IR  luminance : %d lux \n", cData);
	//pr_info("Ambient Light Luminance : %.2f lux \n", luminance);

    return 0;
}
 
/** @brief This function is called whenever device is being read from user space i.e. data is
 *  being sent from the device to the user. In this case is uses the copy_to_user() function to
 *  send the buffer string to the user and captures any errors.
 *  @param filep A pointer to a file object (defined in linux/fs.h)
 *  @param buffer The pointer to the buffer to which this function writes the data
 *  @param len The length of the b
 *  @param offset The offset if required
 */
static ssize_t dev_read(struct file *filep, char *buffer, size_t len, loff_t *offset)
{
   int error_count = 0;
   // copy_to_user has the format ( * to, *from, size) and returns 0 on success
   error_count = copy_to_user(buffer, dataRGB, size_of_msg);

   if (error_count==0)
   {            // if true then have success
      pr_info("devTestI2C: Sent %d characters to the user\n", size_of_msg);
      return 0;
   }
   else 
   {
      pr_info("devTestI2C: Failed to send %d characters to the user\n", error_count);
      return -EFAULT;          // Failed -- return a bad address message (i.e. -14)
   }
}
/** @brief The device open function that is called each time the device is opened
 *  This will only increment the nbrOpens counter in this case.
 *  @param inodep A pointer to an inode object (defined in linux/fs.h)
 *  @param filep A pointer to a file object (defined in linux/fs.h)
 */
static int dev_open(struct inode *inodep, struct file *filep)
{
	thread = kthread_create(thread_function,NULL,"Thread");
	if(thread) {
		wake_up_process(thread);
	} else {
		pr_err("Cannot create kthread\n");
		return -1;
	}
	pr_info("drvTestI2C: start thread\n");
	return 0;
}

/** @brief The device release function that is called whenever the device is closed/released by
 *  the userspace program
 *  @param inodep A pointer to an inode object (defined in linux/fs.h)
 *  @param filep A pointer to a file object (defined in linux/fs.h)
 */
static int dev_release(struct inode *inodep, struct file *filep)
{
	kthread_stop(thread);
	pr_info("drvTestI2C: stop thread\n");
	return 0;
}
/*
** This function getting called when the slave has been found
** Note : This will be called only once when we load the driver.
*/
static int tcs_probe(struct i2c_client *client, const struct i2c_device_id *id)
{
    //SSD1306_DisplayInit();
    
    //fill the OLED with this data
    //SSD1306_Fill(0xFF);
 
    pr_info("TCS Probed!!!\n");
    
    return 0;
}
 
/*
** This function getting called when the slave has been removed
** Note : This will be called only once when we unload the driver.
*/
static int tcs_remove(struct i2c_client *client)
{   
    //fill the OLED with this data
    //SSD1306_Fill(0x00);
    
    pr_info("TCS Removed!!!\n");
    return 0;
}
 
/*
** Structure that has slave device id
*/
static const struct i2c_device_id tcs_id[] = {
        { SLAVE_DEVICE_NAME, 0 },
        { }
};
MODULE_DEVICE_TABLE(i2c, tcs_id);
 
/*
** I2C driver Structure that has to be added to linux
*/
static struct i2c_driver tcs_driver = {
        .driver = {
            .name   = SLAVE_DEVICE_NAME,
            .owner  = THIS_MODULE,
        },
        .probe          = tcs_probe,
        .remove         = tcs_remove,
        .id_table       = tcs_id,
};
 
/*
** I2C Board Info strucutre
*/
static struct i2c_board_info tcs_i2c_board_info = {
        I2C_BOARD_INFO(SLAVE_DEVICE_NAME, TCS_SLAVE_ADDR)
    };
 
/*
** Module Init function
*/
static int __init tcs_driver_init(void)
{
	int ret = -1;

	// Try to dynamically allocate a major number for the device
	majorNumber = register_chrdev(0, DEVICE_NAME, &fops);
	if (majorNumber<0)
	{
	  pr_alert("devTestI2C: failed to register a major number\n");
	  return majorNumber;
	}
	pr_info("devTestI2C: registered (major number %d)\n", majorNumber);

	// Register the device class
	devTestClass = class_create(THIS_MODULE, CLASS_NAME);
	if (IS_ERR(devTestClass))
	{  // Check for error and clean up if there is
	  unregister_chrdev(majorNumber, DEVICE_NAME);
	  pr_alert("Failed to register device class\n");
	  return PTR_ERR(devTestClass);  // Return an error on a pointer
	}
	pr_info("devTest: device class registered\n");

	// Register the device driver
	devTestDevice = device_create(devTestClass, NULL, MKDEV(majorNumber, 0), NULL, DEVICE_NAME);
	if (IS_ERR(devTestDevice))
	{  // Clean up if there is an error
	  class_destroy(devTestClass);          
	  unregister_chrdev(majorNumber, DEVICE_NAME);
	  pr_alert("Failed to create the device\n");
	  return PTR_ERR(devTestDevice);
	}
	pr_info("devTestI2C: device class created\n");

	tcs_i2c_adapter     = i2c_get_adapter(I2C_BUS_AVAILABLE);
	if( tcs_i2c_adapter != NULL )
	{
		tcs_i2c_client = i2c_new_client_device(tcs_i2c_adapter, &tcs_i2c_board_info);      
		if( tcs_i2c_client != NULL )
		{
		    i2c_add_driver(&tcs_driver);
		    ret = 0;
		}
		
		i2c_put_adapter(tcs_i2c_adapter);
	}
	TCS_init();

	pr_info("Driver Added!!!\n");
	return ret;
}
 
/*
** Module Exit function
*/
static void __exit tcs_driver_exit(void)
{
	device_destroy(devTestClass, MKDEV(majorNumber, 0)); 	// remove the device
	class_unregister(devTestClass);                          // unregister the device class
	class_destroy(devTestClass);                             // remove the device class
	unregister_chrdev(majorNumber, DEVICE_NAME);             // unregister the major number
	i2c_unregister_device(tcs_i2c_client);
	i2c_del_driver(&tcs_driver);
	pr_info("Driver Removed!!!\n");
}
 
module_init(tcs_driver_init);
module_exit(tcs_driver_exit);
 
MODULE_LICENSE("GPL");
MODULE_AUTHOR("FSA <blabla@gmail.com>");
MODULE_DESCRIPTION("Simple I2C driver explanation");
MODULE_VERSION("1.10");
