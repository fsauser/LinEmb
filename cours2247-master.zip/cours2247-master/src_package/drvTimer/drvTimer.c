/**
 * @file   drvTimer.c
 * @author FSA
 * @date   15.02.2023
 * @version 0.1
 * @brief   Character driver : timer
 *
 */
 
#include <linux/module.h>     	/* Needed by all modules 			*/
#include <linux/kernel.h>     	/* Needed for KERN_INFO 			*/
#include <linux/init.h>       	/* Needed for the macros 			*/
#include <linux/fs.h>           /* Header for the Linux file system support 	*/
#include <linux/uaccess.h>      /* Required for the copy to user function	*/
#include <linux/moduleparam.h> 	/* Needed for module parameters 		*/
#include <linux/device.h>       /* Header to support the kernel Driver Model	*/
#include <linux/cdev.h>
#include <linux/timer.h>	      /* Header to support the timer kernel 		*/
#include <linux/jiffies.h>	    /* Header to support the timer kernel 		*/
#include <linux/gpio.h>		      /* Header to support GPIO	 		*/

#define  DEVICE_NAME "drvTimer"	/* The device will appear at /dev/drvTimer using this value	*/
#define  CLASS_NAME  "hearc"   	/* The device class -- this is a character device driver	*/

MODULE_LICENSE("GPL");         	
MODULE_AUTHOR("FSA");    		
MODULE_DESCRIPTION("A simple Linux timer driver for RPi4"); 	
MODULE_VERSION("0.2");           

static uint16_t timerSpeed = 1000;

static int nbrOpens = 0;

dev_t dev = 0;
static struct class* drvTimerClass = NULL; 	/* The device-driver class struct pointer			*/
static struct device* drvTimerDevice = NULL; /* The device-driver device struct pointer		*/
static struct cdev drvTimerCdev;

#define GPIO_LED_PIN 5
void timerLED_fct(struct timer_list *);
struct timer_list timerLED;

// Prototype functions for the character driver
static int     dev_open(struct inode *, struct file *);
static int     dev_release(struct inode *, struct file *);
static ssize_t dev_read(struct file *, char *, size_t, loff_t *);
static ssize_t dev_write(struct file *, const char *, size_t, loff_t *);

/** @brief Devices are represented as file structure in the kernel. 
 *  The file_operations structure from /linux/fs.h lists the callback functions that you wish to 
 *  associated with your file operations using a C99 syntax structure. 
 *  char devices usually implement open, read, write and release calls
 */
static struct file_operations fops =
{
  .open = dev_open,
  .read = dev_read,
  .write = dev_write,
  .release = dev_release,
};

/** @brief The initialization function
 *  The static keyword restricts the visibility of the function to within this C file. 
 *  The __init macro means that for a built-in driver the function is only used at initialization
 *  time and that it can be discarded and its memory freed up after that point.
 *  @return returns 0 if successful
 */
static int __init devTimer_init(void)
{
  int ret;
  
  pr_info("devTimer: Initializing the devTimer driver\n");
	/* Allocating Major number */
  if((alloc_chrdev_region(&dev, 0, 1, "drvTimer")) <0)
	{
    pr_err("Cannot allocate major number\n");
    goto err_reg;
  }
  pr_info("Major = %d Minor = %d \n", MAJOR(dev), MINOR(dev));

  /* Creating struct class */
  drvTimerClass = class_create(THIS_MODULE, "drvTimerClass");
  if(IS_ERR(drvTimerClass))
	{
    pr_err("Cannot create the struct class\n");
    goto err_class;
  }

  /* Creating cdev structure */
  cdev_init(&drvTimerCdev, &fops);

  /* Adding character device to the system */
  ret = cdev_add(&drvTimerCdev, dev, 1);
  if( ret < 0)
	{
    pr_err("Cannot add the device to the system\n");
    goto err_cdev;
  }

  /* Creating device */
  drvTimerDevice = device_create(drvTimerClass, NULL, dev, NULL,"drvTimer");
  if( drvTimerDevice == NULL)
	{
    pr_err("Cannot create the Device \n");
    goto err_device;
  }

  pr_info("speed [s]: %d\n", timerSpeed);
  
  //Output GPIO configuration
  //Checking the GPIO is valid or not
  if(gpio_is_valid(GPIO_LED_PIN) == false)
  {
    pr_err("GPIO %d is not valid\n", GPIO_LED_PIN);
    goto err_device;
  }
  //Requesting the GPIO
  if(gpio_request(GPIO_LED_PIN,"GPIO_LED_PIN") < 0)
  {
    pr_err("ERROR: GPIO %d request\n", GPIO_LED_PIN);
    goto err_gpio;
  } 
  //configure the GPIO as output
  gpio_direction_output(GPIO_LED_PIN, 0);
  
  //set timer
  timer_setup(&timerLED, timerLED_fct, 0);
  mod_timer(&timerLED, jiffies + msecs_to_jiffies(timerSpeed));

	pr_info("drvTimer: Initializing the drvTimer driver\n");   
	return 0;

err_gpio:
  gpio_free(GPIO_LED_PIN);
err_device:
  device_destroy(drvTimerClass, dev);
err_cdev:
  cdev_del(&drvTimerCdev);
err_class:
  class_destroy(drvTimerClass);	
err_reg:
  unregister_chrdev_region(dev, 1);
  return -1;
}

/** @brief The cleanup function
 *  Similar to the initialization function, it is static. 
 *  The __exit macro notifies that if this code is used for a built-in driver 
 *  that this function is not required.
 */
static void __exit devTimer_exit(void)
{
  device_destroy(drvTimerClass, dev);
  class_destroy(drvTimerClass);
  cdev_del(&drvTimerCdev);
  unregister_chrdev_region(dev, 1);
  del_timer(&timerLED);
  gpio_free(GPIO_LED_PIN);
  pr_info("devTimer: Goodbye!\n");
}

void timerLED_fct(struct timer_list *timer)
{
  static int count = 0;

  //pr_info("HZ: %d \n",HZ);
  mod_timer(&timerLED, jiffies + (msecs_to_jiffies(500)));
  //pr_info("Timer Occurred : Led --> %d\n", count);
  if (count) 
  {
    gpio_set_value(GPIO_LED_PIN, 1);
    count = 0;
  }
  else 
  {
    gpio_set_value(GPIO_LED_PIN, 0);
    count = 1;
  }
}

/** @brief The device open function that is called each time the device is opened
 *  This will only increment the nbrOpens counter in this case.
 *  @param inodep A pointer to an inode object (defined in linux/fs.h)
 *  @param filep A pointer to a file object (defined in linux/fs.h)
 */
static int dev_open(struct inode *inodep, struct file *filep)
{
  nbrOpens++;
  pr_info("devTimer: Device has been opened %d time(s)\n", nbrOpens);
  return 0;
}

/** @brief This function is called whenever device is being read from user space i.e. data is
 *  being sent from the device to the user. In this case is uses the copy_to_user() function to
 *  send the buffer string to the user and captures any errors.
 *  @param filep A pointer to a file object (defined in linux/fs.h)
 *  @param buffer The pointer to the buffer to which this function writes the data
 *  @param len The length of the b
 *  @param offset The offset if required
 */
static ssize_t dev_read(struct file *filep, char *buffer, size_t len, loff_t *offset)
{
/*
   int error_count = 0;
   // copy_to_user has the format ( * to, *from, size) and returns 0 on success
   error_count = copy_to_user(buffer, message, size_of_msg);

   if (error_count==0)
   {            // if true then have success
      pr_info("devTimer: Sent %d characters to the user\n", size_of_msg);
      return (size_of_msg=0);  // clear the position to the start and return 0
   }
   else 
   {
      pr_info("devTimer: Failed to send %d characters to the user\n", error_count);
      return -EFAULT;          // Failed -- return a bad address message (i.e. -14)
   }*/
   return 0; 
}

/** @brief This function is called whenever the device is being written to from user space i.e.
 *  data is sent to the device from the user. The data is copied to the message[] array in this
 *  using the sprintf() function along with the length of the string.
 *  @param filep A pointer to a file object
 *  @param buffer The buffer to that contains the string to write to the device
 *  @param len The length of the array of data that is being passed in the const char buffer
 *  @param offset The offset if required
 */
static ssize_t dev_write(struct file *filep, const char *buffer, size_t len, loff_t *offset)
{
  uint8_t * pData = (uint8_t *)&timerSpeed;
  
  if (len>2) len=2;
  if(copy_from_user(pData, buffer, len ) > 0) 
  {
    pr_err("ERROR: Not all the bytes have been copied from user\n");
  }
  pr_info("speed [s]: %d\n", timerSpeed);
  return len;
}

/** @brief The device release function that is called whenever the device is closed/released by
 *  the userspace program
 *  @param inodep A pointer to an inode object (defined in linux/fs.h)
 *  @param filep A pointer to a file object (defined in linux/fs.h)
 */
static int dev_release(struct inode *inodep, struct file *filep)
{
  pr_info("devTimer: Device closed\n");
  return 0;
}

/** @brief A module must use the module_init() module_exit() macros from linux/init.h, which
 *  identify the initialization function at insertion time and the cleanup function (as
 *  listed above)
 */
module_init(devTimer_init);
module_exit(devTimer_exit);
