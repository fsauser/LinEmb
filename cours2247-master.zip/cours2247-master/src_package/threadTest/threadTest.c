/**
 * @file   threadTest.c
 * @author FSA
 * @date   26.03.2023
 * @version 0.2
 * @brief   Simple Linux device driver (Kernel Thread)
 *
 */
#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/module.h>
#include <linux/kdev_t.h>
#include <linux/fs.h>
#include <linux/cdev.h>
#include <linux/device.h>
#include <linux/slab.h>         	//kmalloc()
#include <linux/uaccess.h>          //copy_to/from_user()
#include <linux/kthread.h>          //kernel threads
#include <linux/sched.h>            //task_struct 
#include <linux/delay.h>
 
 
dev_t dev = 0;
static struct class*  threadTestClass  = NULL; 
static struct device* threadTestDevice = NULL; 
static struct cdev threadTestCdev;
 
static int __init thread_driver_init(void);
static void __exit thread_driver_exit(void);
 
static struct task_struct *thread;
 
/*
** Function Prototypes
*/
/*************** Driver functions **********************/
static int thread_open(struct inode *inode, struct file *file);
static int thread_release(struct inode *inode, struct file *file);
static ssize_t thread_read(struct file *filp, 
                char __user *buf, size_t len,loff_t * off);
static ssize_t thread_write(struct file *filp, 
                const char *buf, size_t len, loff_t * off);
 /******************************************************/
 
int thread_function(void *pv);

/*
** Thread
*/
int thread_function(void *pv)
{
  int i=0;
  while(!kthread_should_stop()) 
	{
    pr_info("Thread Function %d\n", i++);
    msleep(1000);
  }
  return 0;
}

/*
** File operation sturcture
*/ 
static struct file_operations fops =
{
  .owner          = THIS_MODULE,
  .read           = thread_read,
  .write          = thread_write,
  .open           = thread_open,
  .release        = thread_release,
};

/*
** This function will be called when we open the Device file
*/  
static int thread_open(struct inode *inode, struct file *file)
{
  pr_info("Device File Opened...!!!\n");
  return 0;
}

/*
** This function will be called when we close the Device file
*/   
static int thread_release(struct inode *inode, struct file *file)
{
  pr_info("Device File Closed...!!!\n");
  return 0;
}

/*
** This function will be called when we read the Device file
*/
static ssize_t thread_read(struct file *filp, char __user *buf, size_t len, loff_t *off)
{
  pr_info("Read function\n");
 
  return 0;
}

/*
** This function will be called when we write the Device file
*/
static ssize_t thread_write(struct file *filp, const char __user *buf, size_t len, loff_t *off)
{
  pr_info("Write Function\n");
  return len;
}

/*
** Module Init function
*/  
static int __init thread_driver_init(void)
{
  int ret;
	/* Allocating Major number */
  if((alloc_chrdev_region(&dev, 0, 1, "threadTest")) <0)
	{
    pr_err("Cannot allocate major number\n");
    goto err_reg;
  }
  pr_info("Major = %d Minor = %d \n", MAJOR(dev), MINOR(dev));

  /* Creating struct class */
  threadTestClass = class_create(THIS_MODULE, "threadTestClass");
  if(IS_ERR(threadTestClass))
	{
    pr_err("Cannot create the struct class\n");
    goto err_class;
  }

  /* Creating cdev structure */
  cdev_init(&threadTestCdev, &fops);

  /* Adding character device to the system */
  ret = cdev_add(&threadTestCdev, dev, 1);
  if( ret < 0)
	{
    pr_err("Cannot add the device to the system\n");
    goto err_cdev;
  }

  /* Creating device */
  threadTestDevice = device_create(threadTestClass, NULL, dev, NULL,"threadTest");
  if( threadTestDevice == NULL)
	{
    pr_err( "Cannot create the Device \n");
    goto err_device;
  }

	/* Creating thread */
	thread = kthread_create(thread_function,NULL,"Thread");
  if(thread) 
	{
    wake_up_process(thread);
  } else 
	{
    pr_err("Cannot create kthread\n");
    goto err_device;
  }

	pr_info("threadTest: Initializing the threadTest driver\n");   
	return 0;

err_device:
  device_destroy(threadTestClass, dev);
err_cdev:
  cdev_del(&threadTestCdev);
err_class:
  class_destroy(threadTestClass);	
err_reg:
  unregister_chrdev_region(dev, 1);
  
  return -1;
}

/*
** Module exit function
*/  
static void __exit thread_driver_exit(void)
{
  kthread_stop(thread);
  device_destroy(threadTestClass, dev);	 	// remove the device
  cdev_del(&threadTestCdev);              // remove character device to the system 
  class_destroy(threadTestClass);         // remove the device class
  unregister_chrdev_region(dev, 1);     	// unregister major number
  pr_info("drvTest: Goodbye!\n");
}
 
module_init(thread_driver_init);
module_exit(thread_driver_exit);
 
MODULE_LICENSE("GPL");
MODULE_AUTHOR("FSA <blabla@gmail.com>");
MODULE_DESCRIPTION("A simple device driver - Kernel Thread");
MODULE_VERSION("0.2");

