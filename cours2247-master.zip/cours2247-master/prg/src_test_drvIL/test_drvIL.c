/**
 * @file   test_drvILc
 * @author FSA
 * @date   25.04.2022
 * @version 0.1
 * @brief  A Linux user space program that communicates with the drvTest driver.
 * It passes a string to the driver and reads the response from it.
 * For this example to work the device must be called /dev/drvTest
*/

#include<stdio.h>
#include<stdlib.h>
#include<errno.h>
#include<fcntl.h>
#include<string.h>
#include<unistd.h>

#define BUFFER_LENGTH 300               // The buffer length 
static int receive[300];     // The receive buffer from the driver

int main()
{
   int ret, fd;
   char stringToSend[BUFFER_LENGTH];
   printf("Starting device test code example...\n");
   fd = open("/dev/drvIL", O_RDONLY);             // Open the device with read/write access
   if (fd < 0)
   {
      perror("Failed to open the device...");
      return errno;
   }
  

   printf("Reading from the device...\n");
   
   
   while(true)
   {
	ret = read(fd, receive, BUFFER_LENGTH);        // Read the response from the driver
	if (ret < 0){
	      perror("Failed to read the message from the device.");
	      return errno;
	   }
	   double somX=0;
	   double somY=0;
	   double somZ=0;
	   
	   for(int i=1;i<=100;i++)
	   {
	   	//printf("%i: x=%i y=%i z=%i\n",i,receive[i-1],receive[100+(i-1)],receive[200+(i-1)]);
	   	somX+=receive[i-1];
	   	somY+=receive[100+(i-1)];
	   	somZ+=receive[200+(i-1)];
	   }
	   
	   somX=somX/100.0;
	   somY=somY/100.0;
	   somZ=somZ/100.0;
	   
   	printf("~ x=%.2f y=%.2f z=%.2f\n",somX,somY,somZ);
   	usleep(500000);
   }
   
   /*for(int i=1;i<=30;i++)
   {
   	printf("%i:%i\n",i,receive[i-1]);
   }*/
   
   if(close(fd)==0)
   	printf("drv close\n");
   else
   	printf("drv close fail\n");
   printf("End of the program\n");
   return 0;
}
