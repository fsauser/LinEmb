#ifndef DATA_H
#define DATA_H

#include <QString>

#include <iostream>
#include <unistd.h>
#include <fcntl.h>
#include <sstream>



class Data
{
public:
    static QString getData();

};


#endif
