#include <QtCore>

#include "data.h"

QString Data::getData()
{
    int receive[300];
    int ret, fd;
    char stringToSend[300];
    fd = open("/dev/drvIL", O_RDONLY|O_NONBLOCK);      
    ret = read(fd, receive, 300);
    QString out;
    for(int i=1;i<=100;i++)
    {
    	out.append(QString::number(receive[i-1]));
    	out.append(",");
    	out.append(QString::number(receive[100+(i-1)]));
    	out.append(",");
    	out.append(QString::number(receive[200+(i-1)]));
    	out.append(";");
    }
    return out;
}
