#include <stdio.h>
#include <iostream> 
#include <stdlib.h>
using namespace std;

int main (int argc, char* argv[])
{
    cout << "ip addr. : ip";
	cout << "Le nom de ce programme est " << argv[0] << endl ;
	cout << "Ce programme a été invoqué avec " << argc - 1 << " arguments\n";
	if (argc > 1) 
	{
		int i;
		cout << "Les arguments sont :\n";
		for (i = 1; i < argc; ++i)
		{
			cout << i << ".) " << argv[i] << endl;
			system(argv[i]);
		}
	}
	else
	{
		cout << "pas d'argument\n";
	}
	return 0;
}


