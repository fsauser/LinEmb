#include <iostream> 

using namespace std;

int main (int argc, char* argv[])
{
  cout << "Le nom de ce programme est " << argv[0] << endl ;
  cout << "Ce programme a été invoqué avec " << argc - 1 << " arguments" << endl;
  if (argc > 1) 
  {
    cout << "Les arguments sont :" << endl;
    for (int i = 1; i < argc; ++i)
    {
      cout << i << ".) " << argv[i] << endl;
      system(argv[i]);
    }
  }
  else
  {
    cout << "pas d'argument" << endl;
  }
  return 0;
}


