#include <iostream>
#include <unistd.h>
#include <sys/wait.h>

using namespace std;

int main(int argc, char *argv[])
{
   cout << "Parent process: " << (int) getpid() << endl;

   pid_t pid = fork();
   //cout << "fork returned: " << (int) pid << endl;

   if (pid < 0) 
   { 
       perror("Fork failed\n");
   }
   if (pid == 0) 
   { // child process 
       cout << "Child process with pid " << (int) getpid() << endl;
       sleep(5);
       cout << "Child process is exiting" << endl;
       exit(0);
   }
   // parent process 
   cout << "Parent process waiting for the child process to end" << endl;
   //sleep(15); //a jout de cette ligne pour creer un processus zombie durant 10s
   wait(NULL);
   cout << "Parent process is exiting\n";
   return(0);
} 
