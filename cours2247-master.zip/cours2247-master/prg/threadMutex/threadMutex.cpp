#include <thread>
#include <iostream>
#include <vector>
#include <mutex>

using namespace std;

static mutex mtx;

void doSomething(int id) 
{
  mtx.lock();
  cout <<"Bonjour, je suis le Thread["<<id << "]" << endl;
  mtx.unlock();
}

void spawnThreads(int n) 
{
  vector<thread> threads(n);
  
  for (int i = 0; i < n; i++) 
  {
    threads[i] = thread(doSomething, i + 1);
  }
  for (thread& th : threads) 
  {
    th.join();
  }
  
  cout <<"Au revoir!" << endl;
}

int main(int argc, char *argv[])
{
  if (argc>1) spawnThreads(atoi(argv[1]));
  return 0;
}

