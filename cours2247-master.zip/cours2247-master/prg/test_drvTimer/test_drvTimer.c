/**
 * @file   test_drvTimer.c
 * @author FSA
 * @date   25.03.2023
 * @version 0.2
 * @brief  A Linux user space program that communicates with the drvTimer driver.
 * For this example to work the device must be called /dev/drvTimer
*/

#include<stdio.h>
#include<stdlib.h>
#include<errno.h>
#include<fcntl.h>
#include<unistd.h>
#include<stdint.h>


int main()
{
   int ret=1, fd;
   uint16_t speed;
   printf("Starting device test code example...\n");
   fd = open("/dev/drvTimer", O_RDWR);             // Open the device with read/write access
   if (fd < 0)
   {
      perror("Failed to open the device...");
      return errno;
   }
   
   while(ret>0)
   {
     printf("Enter speed of blink: ");
     scanf("%hu", &speed);              
     ret = write(fd, &speed, 2);//size_of(speed));
   }

   printf("End of the program\n");
   return 0;
}
