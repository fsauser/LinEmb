#include <iostream>
#include <cstdlib>
#include <pthread.h>
#include <time.h>
#include <unistd.h>


using namespace std;

#define NUM_THREADS 5

void *printMsg(void *threadid) 
{
   long tid;
   tid = (long)threadid;
   cout << "Thread ID, " << tid << endl;
   for(int i=0;i<10;i++)
   {
       cout << "-";
       usleep(1000000);
   }
   cout << "end\n";
   pthread_exit(NULL);
}

int main () 
{
   pthread_t threads[NUM_THREADS];
   int rc;
   int i;
   
   for(i = 0; i < NUM_THREADS; i++) 
   {
      cout << "main() : creating thread, " << i << endl;
      rc = pthread_create(&threads[i], NULL, printMsg, (void *)(long)i);
      
      if (rc) 
      {
         cout << "Error:unable to create thread," << rc << endl;
         exit(-1);
      }
   }
   
   for(i = 0; i < NUM_THREADS; i++) 
   {
   	  pthread_join(threads[i], NULL);
   }
   
   pthread_exit(NULL);
}


