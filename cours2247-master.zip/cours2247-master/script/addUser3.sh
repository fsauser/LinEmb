#!/bin/sh

mkdir pi4-config
cd pi4-config

echo "name: PI4_CONFIG" > external.desc
echo "desc: Custom configuration for Pi 4" >> external.desc
cat external.desc

touch external.mk
touch Config.in
mkdir configs

echo "rpi 1000 rpi 1000 =rpi /home/rpi /bin/sh - Raspberry Pi User" > configs/users.tbl

cd ../build-pi4/
export BR2_EXTERNAL=../pi4-config/
make menuconfig

