#!/bin/sh

cp ../pi4-config/configs/buildroot.config ../build-pi4/.config
cp ../pi4-config/configs/linux.config ../build-pi4/build/linux-custom/.config
cp ../pi4-config/configs/busybox.config ../build-pi4/build/busybox-1.35.0/.config
cp ../pi4-config/configs/uclibc.config ../build-pi4/build/uclibc-1.0.40/.config
