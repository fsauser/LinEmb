#!/bin/sh

cp ../build-pi4/.config ../pi4-config/configs/buildroot.config
cp ../build-pi4/build/linux-custom/.config ../pi4-config/configs/linux.config
cp ../build-pi4/build/busybox-1.35.0/.config ../pi4-config/configs/busybox.config
cp ../build-pi4/build/uclibc-1.0.40/.config ../pi4-config/configs/uclibc.config

