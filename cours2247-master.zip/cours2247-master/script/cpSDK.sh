#!/bin/sh

cd ../build-pi4
make sdk
sudo tar xf images/arm-buildroot-linux-uclibcgnueabihf_sdk-buildroot.tar.gz -C /opt/
sudo rm -r /opt/cross-br
sudo mv /opt/arm-buildroot-linux-uclibcgnueabihf_sdk-buildroot/ /opt/cross-br
cd /opt/cross-br
sudo ./relocate-sdk.sh
cd 
cd dev/build-pi4

