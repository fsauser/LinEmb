#!/bin/sh
#wget http://www.buildroot.org/downloads/buildroot-2021.02.10.tar.bz2
#tar -xjvf buildroot-2021.02.10.tar.bz2
wget http://www.buildroot.org/downloads/buildroot-2022.02.tar.gz
tar -xzvf buildroot-2022.02.tar.gz
mv buildroot-2022.02/ buildroot
chmod -R -w buildroot

cd buildroot
ls configs/

make O=../build-pi4 raspberrypi4_defconfig
cd ../build-pi4/

make menuconfig

make -j4

